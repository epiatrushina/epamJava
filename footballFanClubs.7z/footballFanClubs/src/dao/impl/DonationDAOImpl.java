package dao.impl;

import java.util.List;

import dao.DonationDAO;
import domain.Donation;

public class DonationDAOImpl implements DonationDAO {
    @Override
    public Donation create(Donation entity) {
        return null;
    }

    @Override
    public Donation read(long id) {
        return null;
    }

    @Override
    public List<Donation> readAll() {
        return null;
    }

    @Override
    public void update(Donation entity) {}

    @Override
    public void delete(Donation entity) {}
}