package dao;

import domain.Donation;

public interface DonationDAO extends GenericDAO<Donation> {}